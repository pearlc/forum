/*
SQLyog Community v9.33 GA
MySQL - 5.1.41-community : Database - gtaforum
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`gtaforum` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `gtaforum`;

/*Table structure for table `ci_sessions` */

DROP TABLE IF EXISTS `ci_sessions`;

CREATE TABLE `ci_sessions` (
  `session_id` varchar(40) COLLATE utf8_bin NOT NULL DEFAULT '0',
  `ip_address` varchar(16) COLLATE utf8_bin NOT NULL DEFAULT '0',
  `user_agent` varchar(150) COLLATE utf8_bin NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `ci_sessions` */

insert  into `ci_sessions`(`session_id`,`ip_address`,`user_agent`,`last_activity`,`user_data`) values ('0dd729fa477a50c5c5024397416224ba','127.0.0.1','Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.97 Safari/537.11',1357327243,''),('1fb2901734fb746175b9b26deeb38e31','127.0.0.1','Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.97 Safari/537.11',1357356312,''),('2937c01e0f501226f20b82a3d495712c','127.0.0.1','Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.97 Safari/537.11',1357327243,''),('3185e33da255d93b7ebb0a91d4358848','127.0.0.1','Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.97 Safari/537.11',1357356312,''),('4d7e4fb89943f220f291e2f8c31a6690','127.0.0.1','Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.97 Safari/537.11',1357356315,''),('601a13652c25b7ef2e01916da509e922','127.0.0.1','Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.97 Safari/537.11',1357711726,''),('bc68cdd350acb83722b7da6743ab4851','127.0.0.1','Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.97 Safari/537.11',1357356312,''),('c9da97836b87d517c6a3c33d1c69289f','127.0.0.1','Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.97 Safari/537.11',1357327243,'');

/*Table structure for table `freeboard_articles` */

DROP TABLE IF EXISTS `freeboard_articles`;

CREATE TABLE `freeboard_articles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `ip` varchar(40) NOT NULL,
  `hit` int(11) NOT NULL DEFAULT '0',
  `recommend` int(9) NOT NULL DEFAULT '0',
  `report` int(4) NOT NULL DEFAULT '0',
  `comments_count` int(6) NOT NULL DEFAULT '0',
  `deleted` tinyint(4) NOT NULL DEFAULT '0',
  `delete_code` tinyint(4) DEFAULT NULL,
  `content` text NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

/*Data for the table `freeboard_articles` */

insert  into `freeboard_articles`(`id`,`title`,`user_id`,`username`,`ip`,`hit`,`recommend`,`report`,`comments_count`,`deleted`,`delete_code`,`content`,`created`,`modified`) values (1,'테스트용 글 제목',3,'jinho','127.0.0.1',0,10,20,1,0,NULL,'<p>심플한 글. 내용임</p>','2013-01-10 21:22:31','2013-01-10 21:22:31'),(2,'두번째 테스트 제목',3,'jinho','127.0.0.1',101,2,1,2,0,NULL,'<p>두번째 테스트 글</p>\r\n<p>흠냐. 내용임</p>','2013-01-10 21:23:49','2013-01-10 21:23:49'),(3,'세번째 제목',3,'jinho','127.0.0.1',2,0,0,0,0,NULL,'<p>가나다라</p>','2013-01-11 01:14:45','2013-01-11 01:14:45'),(4,'테스트 글임미당',3,'jinho','127.0.0.1',0,0,0,0,0,NULL,'<p>가나다라</p>','2013-01-13 15:38:47','2013-01-13 15:38:47'),(5,'ㅁㅇㄻㅇㄹ',3,'jinho','127.0.0.1',0,0,0,0,0,NULL,'<p>가나다라</p>','2013-01-13 15:39:15','2013-01-13 15:39:15'),(6,'zzzzz',3,'jinho','127.0.0.1',0,0,0,0,0,NULL,'<p>가나다라</p>','2013-01-13 15:41:56','2013-01-13 15:41:56'),(7,'동작해랏!!',3,'jinho','127.0.0.1',0,0,0,0,0,NULL,'<p>ㅗ허ㅗㅎ</p>','2013-01-13 15:42:46','2013-01-13 15:42:46'),(8,'ㅂㅂㅂㅂ',3,'jinho','127.0.0.1',0,0,0,0,0,NULL,'<p>ㅗ허ㅗㅎ</p>','2013-01-13 15:44:33','2013-01-13 15:44:33'),(9,'진지한 글입니다',3,'jinho','127.0.0.1',0,0,0,0,0,NULL,'<p>전 진지합니다. 진짜라니까요. 이 줄은길어야 합니다. 테스트를 해야하기 때문이죠. 줄이 많이 길어서 한 줄을 꽉 채우고 다음줄로 넘어가야 되요. 그래서 제가 이렇게 진지한겁니다. 아직 많이 남았어요. 더 길어야되요.&nbsp;테스트를 해야하기 때문이죠. 줄이 많이 길어서 한 줄을 꽉 채우고 다음줄로 넘어가야 되요. 그래서 제가 이렇게 진지한겁니다. 아직 많이 남았어요. 더 길어야되요.&nbsp;</p><p>이건 다음 단락이에요.&nbsp;테스트를 해야하기 때문이죠. 줄이 많이 길어서 한 줄을 꽉 채우고 다음줄로 넘어가야 되요. 그래서 제가 이렇게 진지한겁니다. 아직 많이 남았어요. 더 길어야되요.&nbsp;테스트를 해야하기 때문이죠. 줄이 많이 길어서 한 줄을 꽉 채우고 다음줄로 넘어가야 되요. 그래서 제가 이렇게 진지한겁니다. 아직 많이 남았어요. 더 길어야되요.&nbsp;</p><ol><li>일이삼사요</li><li>일이삼사오 2</li></ol><p>헤헤헤헤&nbsp;</p><ul><li>이건 ul</li><li>글치?</li></ul><p>링크를 걸어봅시다. <a href=\"http://naver.com\">네이버</a>로 가기</p><p>이미지를 삽입해봅시다.테스트를 해야하기 때문이죠. 줄이 많이 길어서 한 줄을 꽉 채우고 다음줄로 넘어가야 되요. 그래서 제가 이렇게 진지한겁니다. 아직 많이 남았어요. 더 길어야되요.&nbsp;테스트를 해야하기 때문이죠. 줄이 많이 길어서 한 줄을 꽉 채우고 다음줄로 넘어가야 되요. 그래서 제가 이렇게 진지한겁니다. 아직 많이 남았어요. 더 길어야되요. 단락 안에서 바로 이미지를 넣어봅시다<img alt=\"\" src=\"http://imgnews.naver.net/image/109/2013/01/13/201301130223772271_50f19d4f8f7c4_59_20130113062002.jpg\" />이미지 옆에 글씨를 쓰면 이렇게 됨</p><p>다음줄로 넘어가는듯 싶넹</p><p>이건 ctrl+c , ctrl+v</p><p><br /><br />[OSEN=김태우 기자] 류현진(26, LA 다저스)이<br />&nbsp;</p><p>&nbsp;</p>','2013-01-13 15:57:15','2013-01-13 15:57:15');

/*Table structure for table `freeboard_comments` */

DROP TABLE IF EXISTS `freeboard_comments`;

CREATE TABLE `freeboard_comments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `article_id` int(11) NOT NULL,
  `depth` tinyint(4) NOT NULL COMMENT '0이면 일반댓글, 1이면 댓글의 댓글. 1이 최대.',
  `parent_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `ip` varchar(40) NOT NULL,
  `recommend` int(11) NOT NULL,
  `report` int(11) NOT NULL,
  `deleted` tinyint(4) NOT NULL,
  `delete_code` tinyint(4) NOT NULL,
  `content` text NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `freeboard_comments` */

/*Table structure for table `login_attempts` */

DROP TABLE IF EXISTS `login_attempts`;

CREATE TABLE `login_attempts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(40) COLLATE utf8_bin NOT NULL,
  `login` varchar(50) COLLATE utf8_bin NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `login_attempts` */

/*Table structure for table `user_autologin` */

DROP TABLE IF EXISTS `user_autologin`;

CREATE TABLE `user_autologin` (
  `key_id` char(32) COLLATE utf8_bin NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `user_agent` varchar(150) COLLATE utf8_bin NOT NULL,
  `last_ip` varchar(40) COLLATE utf8_bin NOT NULL,
  `last_login` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`key_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `user_autologin` */

/*Table structure for table `user_profiles` */

DROP TABLE IF EXISTS `user_profiles`;

CREATE TABLE `user_profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `country` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `website` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `user_profiles` */

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8_bin NOT NULL,
  `password` varchar(255) COLLATE utf8_bin NOT NULL,
  `email` varchar(100) COLLATE utf8_bin NOT NULL,
  `activated` tinyint(1) NOT NULL DEFAULT '1',
  `banned` tinyint(1) NOT NULL DEFAULT '0',
  `ban_reason` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `new_password_key` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `new_password_requested` datetime DEFAULT NULL,
  `new_email` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `new_email_key` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `last_ip` varchar(40) COLLATE utf8_bin NOT NULL,
  `last_login` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `users` */

insert  into `users`(`id`,`username`,`password`,`email`,`activated`,`banned`,`ban_reason`,`new_password_key`,`new_password_requested`,`new_email`,`new_email_key`,`last_ip`,`last_login`,`created`,`modified`) values (3,'jinho','$2a$08$cyjKspXKg0T0KggbeLV96eu9daYXeagHWNnOyz29TrXb3bMMUz59C','pearlc@naver.com',1,0,NULL,NULL,NULL,NULL,NULL,'127.0.0.1','2013-01-13 15:05:35','2013-01-10 15:30:48','2013-01-13 15:05:35');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
