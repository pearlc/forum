# ************************************************************
# Sequel Pro SQL dump
# Version 3408
#
# http://www.sequelpro.com/
# http://code.google.com/p/sequel-pro/
#
# Host: 127.0.0.1 (MySQL 5.5.25)
# Database: gtaforum
# Generation Time: 2013-01-13 07:34:01 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table ci_sessions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `ci_sessions`;

CREATE TABLE `ci_sessions` (
  `session_id` varchar(40) COLLATE utf8_bin NOT NULL DEFAULT '0',
  `ip_address` varchar(16) COLLATE utf8_bin NOT NULL DEFAULT '0',
  `user_agent` varchar(150) COLLATE utf8_bin NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

LOCK TABLES `ci_sessions` WRITE;
/*!40000 ALTER TABLE `ci_sessions` DISABLE KEYS */;

INSERT INTO `ci_sessions` (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`)
VALUES
	(X'3064643732396661343737613530633563353032343339373431363232346261',X'3132372E302E302E31',X'4D6F7A696C6C612F352E30202857696E646F7773204E5420362E3129204170706C655765624B69742F3533372E313120284B48544D4C2C206C696B65204765636B6F29204368726F6D652F32332E302E313237312E3937205361666172692F3533372E3131',1357327243,X''),
	(X'3166623239303137333466623734363137356239623236646565623338653331',X'3132372E302E302E31',X'4D6F7A696C6C612F352E30202857696E646F7773204E5420362E3129204170706C655765624B69742F3533372E313120284B48544D4C2C206C696B65204765636B6F29204368726F6D652F32332E302E313237312E3937205361666172692F3533372E3131',1357356312,X''),
	(X'3239333763303165306635303132323666323062383261336434393537313263',X'3132372E302E302E31',X'4D6F7A696C6C612F352E30202857696E646F7773204E5420362E3129204170706C655765624B69742F3533372E313120284B48544D4C2C206C696B65204765636B6F29204368726F6D652F32332E302E313237312E3937205361666172692F3533372E3131',1357327243,X''),
	(X'3331383565333364613235356439336237656262306139316434333538383438',X'3132372E302E302E31',X'4D6F7A696C6C612F352E30202857696E646F7773204E5420362E3129204170706C655765624B69742F3533372E313120284B48544D4C2C206C696B65204765636B6F29204368726F6D652F32332E302E313237312E3937205361666172692F3533372E3131',1357356312,X''),
	(X'3464376534666238393934336632323066323931653266386333316136363930',X'3132372E302E302E31',X'4D6F7A696C6C612F352E30202857696E646F7773204E5420362E3129204170706C655765624B69742F3533372E313120284B48544D4C2C206C696B65204765636B6F29204368726F6D652F32332E302E313237312E3937205361666172692F3533372E3131',1357356315,X''),
	(X'3630316131333635326332356237656632653031393136646135303965393232',X'3132372E302E302E31',X'4D6F7A696C6C612F352E30202857696E646F7773204E5420362E3129204170706C655765624B69742F3533372E313120284B48544D4C2C206C696B65204765636B6F29204368726F6D652F32332E302E313237312E3937205361666172692F3533372E3131',1357711726,X''),
	(X'6263363863646433353061636238333732326237646136373433616234383531',X'3132372E302E302E31',X'4D6F7A696C6C612F352E30202857696E646F7773204E5420362E3129204170706C655765624B69742F3533372E313120284B48544D4C2C206C696B65204765636B6F29204368726F6D652F32332E302E313237312E3937205361666172692F3533372E3131',1357356312,X''),
	(X'6339646139373833366238376435313763366133633333643163363932383966',X'3132372E302E302E31',X'4D6F7A696C6C612F352E30202857696E646F7773204E5420362E3129204170706C655765624B69742F3533372E313120284B48544D4C2C206C696B65204765636B6F29204368726F6D652F32332E302E313237312E3937205361666172692F3533372E3131',1357327243,X'');

/*!40000 ALTER TABLE `ci_sessions` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table freeboard_articles
# ------------------------------------------------------------

DROP TABLE IF EXISTS `freeboard_articles`;

CREATE TABLE `freeboard_articles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `ip` varchar(40) NOT NULL,
  `hit` int(11) NOT NULL DEFAULT '0',
  `recommend` int(9) NOT NULL DEFAULT '0',
  `report` int(4) NOT NULL DEFAULT '0',
  `comments_count` int(6) NOT NULL DEFAULT '0',
  `deleted` tinyint(4) NOT NULL DEFAULT '0',
  `delete_code` tinyint(4) DEFAULT NULL,
  `content` text NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `freeboard_articles` WRITE;
/*!40000 ALTER TABLE `freeboard_articles` DISABLE KEYS */;

INSERT INTO `freeboard_articles` (`id`, `title`, `user_id`, `username`, `ip`, `hit`, `recommend`, `report`, `comments_count`, `deleted`, `delete_code`, `content`, `created`, `modified`)
VALUES
	(1,'테스트용 글 제목',3,'jinho','127.0.0.1',0,10,20,1,0,NULL,'<p>심플한 글. 내용임</p>','2013-01-10 21:22:31','2013-01-10 21:22:31'),
	(2,'두번째 테스트 제목',3,'jinho','127.0.0.1',101,2,1,2,0,NULL,'<p>두번째 테스트 글</p>\r\n<p>흠냐. 내용임</p>','2013-01-10 21:23:49','2013-01-10 21:23:49'),
	(3,'세번째 제목',3,'jinho','127.0.0.1',2,0,0,0,0,NULL,'<p>가나다라</p>','2013-01-11 01:14:45','2013-01-11 01:14:45'),
	(4,'테스트 글임미당',3,'jinho','127.0.0.1',0,0,0,0,0,NULL,'<p>가나다라</p>','2013-01-13 15:38:47','2013-01-13 15:38:47'),
	(5,'ㅁㅇㄻㅇㄹ',3,'jinho','127.0.0.1',0,0,0,0,0,NULL,'<p>가나다라</p>','2013-01-13 15:39:15','2013-01-13 15:39:15'),
	(6,'zzzzz',3,'jinho','127.0.0.1',0,0,0,0,0,NULL,'<p>가나다라</p>','2013-01-13 15:41:56','2013-01-13 15:41:56'),
	(7,'동작해랏!!',3,'jinho','127.0.0.1',0,0,0,0,0,NULL,'<p>ㅗ허ㅗㅎ</p>','2013-01-13 15:42:46','2013-01-13 15:42:46'),
	(8,'ㅂㅂㅂㅂ',3,'jinho','127.0.0.1',0,0,0,0,0,NULL,'<p>ㅗ허ㅗㅎ</p>','2013-01-13 15:44:33','2013-01-13 15:44:33'),
	(9,'진지한 글입니다',3,'jinho','127.0.0.1',0,0,0,0,0,NULL,'<p>전 진지합니다. 진짜라니까요. 이 줄은길어야 합니다. 테스트를 해야하기 때문이죠. 줄이 많이 길어서 한 줄을 꽉 채우고 다음줄로 넘어가야 되요. 그래서 제가 이렇게 진지한겁니다. 아직 많이 남았어요. 더 길어야되요.&nbsp;테스트를 해야하기 때문이죠. 줄이 많이 길어서 한 줄을 꽉 채우고 다음줄로 넘어가야 되요. 그래서 제가 이렇게 진지한겁니다. 아직 많이 남았어요. 더 길어야되요.&nbsp;</p><p>이건 다음 단락이에요.&nbsp;테스트를 해야하기 때문이죠. 줄이 많이 길어서 한 줄을 꽉 채우고 다음줄로 넘어가야 되요. 그래서 제가 이렇게 진지한겁니다. 아직 많이 남았어요. 더 길어야되요.&nbsp;테스트를 해야하기 때문이죠. 줄이 많이 길어서 한 줄을 꽉 채우고 다음줄로 넘어가야 되요. 그래서 제가 이렇게 진지한겁니다. 아직 많이 남았어요. 더 길어야되요.&nbsp;</p><ol><li>일이삼사요</li><li>일이삼사오 2</li></ol><p>헤헤헤헤&nbsp;</p><ul><li>이건 ul</li><li>글치?</li></ul><p>링크를 걸어봅시다. <a href=\"http://naver.com\">네이버</a>로 가기</p><p>이미지를 삽입해봅시다.테스트를 해야하기 때문이죠. 줄이 많이 길어서 한 줄을 꽉 채우고 다음줄로 넘어가야 되요. 그래서 제가 이렇게 진지한겁니다. 아직 많이 남았어요. 더 길어야되요.&nbsp;테스트를 해야하기 때문이죠. 줄이 많이 길어서 한 줄을 꽉 채우고 다음줄로 넘어가야 되요. 그래서 제가 이렇게 진지한겁니다. 아직 많이 남았어요. 더 길어야되요. 단락 안에서 바로 이미지를 넣어봅시다<img alt=\"\" src=\"http://imgnews.naver.net/image/109/2013/01/13/201301130223772271_50f19d4f8f7c4_59_20130113062002.jpg\" />이미지 옆에 글씨를 쓰면 이렇게 됨</p><p>다음줄로 넘어가는듯 싶넹</p><p>이건 ctrl+c , ctrl+v</p><p><br /><br />[OSEN=김태우 기자] 류현진(26, LA 다저스)이<br />&nbsp;</p><p>&nbsp;</p>','2013-01-13 15:57:15','2013-01-13 15:57:15'),
	(10,'맥북에서 테스트',3,'jinho','::1',0,0,0,0,0,NULL,'<p>github 를 통해 sql문을 복사하고 맥북 db에 그대로 덮어썼습니다.&nbsp;</p><p>이건 <em><strong>맥북에서 맥북서버로 테스트</strong></em> 하는 겁니다</p><p>잘되겠죠, 당연히.</p>','2013-01-13 16:18:58','2013-01-13 16:18:58'),
	(11,'새 계정으로 테스트',4,'jinho11_gmail','::1',0,0,0,0,0,NULL,'<p>새 계정으로 테스트 합니다</p>','2013-01-13 16:20:22','2013-01-13 16:20:22'),
	(12,'집 pc 에서 맥북 서버로 글쓰기',3,'jinho','192.168.0.105',0,0,0,0,0,NULL,'<p>네, 잘 됩니다.&nbsp;</p>','2013-01-13 16:31:16','2013-01-13 16:31:16');

/*!40000 ALTER TABLE `freeboard_articles` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table freeboard_comments
# ------------------------------------------------------------

DROP TABLE IF EXISTS `freeboard_comments`;

CREATE TABLE `freeboard_comments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `article_id` int(11) NOT NULL,
  `depth` tinyint(4) NOT NULL COMMENT '0이면 일반댓글, 1이면 댓글의 댓글. 1이 최대.',
  `parent_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `ip` varchar(40) NOT NULL,
  `recommend` int(11) NOT NULL,
  `report` int(11) NOT NULL,
  `deleted` tinyint(4) NOT NULL,
  `delete_code` tinyint(4) NOT NULL,
  `content` text NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



# Dump of table login_attempts
# ------------------------------------------------------------

DROP TABLE IF EXISTS `login_attempts`;

CREATE TABLE `login_attempts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(40) COLLATE utf8_bin NOT NULL,
  `login` varchar(50) COLLATE utf8_bin NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;



# Dump of table user_autologin
# ------------------------------------------------------------

DROP TABLE IF EXISTS `user_autologin`;

CREATE TABLE `user_autologin` (
  `key_id` char(32) COLLATE utf8_bin NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `user_agent` varchar(150) COLLATE utf8_bin NOT NULL,
  `last_ip` varchar(40) COLLATE utf8_bin NOT NULL,
  `last_login` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`key_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;



# Dump of table user_profiles
# ------------------------------------------------------------

DROP TABLE IF EXISTS `user_profiles`;

CREATE TABLE `user_profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `country` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `website` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

LOCK TABLES `user_profiles` WRITE;
/*!40000 ALTER TABLE `user_profiles` DISABLE KEYS */;

INSERT INTO `user_profiles` (`id`, `user_id`, `country`, `website`)
VALUES
	(1,4,NULL,NULL);

/*!40000 ALTER TABLE `user_profiles` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8_bin NOT NULL,
  `password` varchar(255) COLLATE utf8_bin NOT NULL,
  `email` varchar(100) COLLATE utf8_bin NOT NULL,
  `activated` tinyint(1) NOT NULL DEFAULT '1',
  `banned` tinyint(1) NOT NULL DEFAULT '0',
  `ban_reason` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `new_password_key` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `new_password_requested` datetime DEFAULT NULL,
  `new_email` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `new_email_key` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `last_ip` varchar(40) COLLATE utf8_bin NOT NULL,
  `last_login` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;

INSERT INTO `users` (`id`, `username`, `password`, `email`, `activated`, `banned`, `ban_reason`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created`, `modified`)
VALUES
	(3,X'6A696E686F',X'2432612430382463796A4B7370584B673054304B676762654C5639366575396461595865616748574E6E4F797A32395472586233624D4D557A353943',X'706561726C63406E617665722E636F6D',1,0,NULL,NULL,NULL,NULL,NULL,X'3139322E3136382E302E313035','2013-01-13 16:25:46','2013-01-10 15:30:48','2013-01-13 16:25:46'),
	(4,X'6A696E686F31315F676D61696C',X'24326124303824766D6E5963427137337A616F6637396C6F4755704A2E7734326C2E77746950754B44785172787536664C4C616A5265386B43715969',X'706561726C63313140676D61696C2E636F6D',1,0,NULL,NULL,NULL,NULL,NULL,X'3A3A31','2013-01-13 16:20:03','2013-01-13 16:19:34','2013-01-13 16:20:03');

/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
